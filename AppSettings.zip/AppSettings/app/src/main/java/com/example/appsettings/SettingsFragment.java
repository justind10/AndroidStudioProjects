package com.example.appsettings;

import android.content.Context;
import android.os.Bundle;

import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;

public class SettingsFragment extends PreferenceFragmentCompat{


    public static final String SETTINGS_DATA = "identity_data";
    public static final String EXTRA_LAST_NAME = "identity_last_name";
    public static final String EXTRA_FIRST_NAME = "identity_first_name";

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.identity_preference,rootKey);
        findPreference("first_name").setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                updateFirstName(newValue);
                return true;
            }
        });

     findPreference("last_name").setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
         @Override
         public boolean onPreferenceChange(Preference preference, Object newValue) {
             updateLastName(newValue);
             return true;
         }
     });
    }

    private void updateLastName(Object newValue) {
        getActivity().getSharedPreferences(SETTINGS_DATA, Context.MODE_PRIVATE)
                .edit()
                .putString(EXTRA_LAST_NAME, (String) newValue)
                .apply();
    }

    private void updateFirstName(Object newValue) {
        getActivity().getSharedPreferences(SETTINGS_DATA, Context.MODE_PRIVATE)
                .edit()
                .putString(EXTRA_FIRST_NAME, (String) newValue)
                .apply();
    }
    }



