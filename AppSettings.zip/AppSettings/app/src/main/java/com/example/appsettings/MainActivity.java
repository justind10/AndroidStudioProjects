package com.example.appsettings;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //grab menu and give dropdown
        getMenuInflater().inflate(R.menu.toolbar_menu,menu);
        //get reference of items in settings
        MenuItem settingsMenu = menu.findItem(R.id.settings);
        //when menu is pressed
        settingsMenu.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                navigateSecondActivity();
                return true;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    private void navigateSecondActivity() {
    Intent navigate = new Intent(this,SecondActivity.class);
    startActivity(navigate);

    }
}