package com.example.appsettings;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView tvFirstname,tvLastname;
    Button btnRead;
    Button btnCreate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        tvFirstname = findViewById(R.id.tv_name);
        tvLastname = findViewById(R.id.tv_last_name);
        btnCreate = findViewById(R.id.btn_creating);
        btnRead = findViewById(R.id.btn_read);

        btnCreate.setOnClickListener(view -> {navigateIdentityPreferences();});
        btnRead.setOnClickListener(view ->{});
    }
    private void navigateIdentityPreferences(){
        getSupportFragmentManager().beginTransaction()
                .replace(android.R.id.content,new SettingsFragment())
                .commit();
    }
    private void readFromSP(){
        String fname = getSharedPreferences(SettingsFragment.SETTINGS_DATA, Context.MODE_PRIVATE)
                .getString(SettingsFragment.EXTRA_FIRST_NAME,"");
        String lname = getSharedPreferences(SettingsFragment.SETTINGS_DATA, Context.MODE_PRIVATE)
                .getString(SettingsFragment.EXTRA_LAST_NAME,"");
        tvFirstname.setText(fname);
        tvLastname.setText(lname);

    }

}