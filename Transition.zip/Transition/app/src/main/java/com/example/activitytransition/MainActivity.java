package com.example.activitytransition;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {
    private final static String TAG = "MainActivity";
    /**
     * Init fields, files and connections.
     * It will be called once per lifetime.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Link the XML file with this Activity
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate: ");
        findViewById(R.id.btn_open_activity).setOnClickListener(view -> {
            navigateActivity2();
        });
        //register intent filter at runtime
       // IntentFilter filter= new IntentFilter("OPEN_ACTIVITY_3");
//        Intent sendIntent = new Intent();
//        sendIntent.setAction(Intent.ACTION_SEND);
//        sendIntent.putExtra(Intent.EXTRA_TEXT, "Hello");
//        sendIntent.setType("text/plain");
//
//// Try to invoke the intent.
//        try {
//            startActivity(sendIntent);
//        } catch (ActivityNotFoundException e) {
//            // Define what your app should do if no activity can handle the intent.
//        }
    }

    private void navigateActivity2(){
        //Intents
        //messenger to navigate to Components.
        //Explicit intent[Name of the component to navigate]
        Intent openActivity2 = new Intent();

        openActivity2.setClass(this,Activity2.class);

        startActivity(openActivity2); // Activity
        //sendBroadcast(); Broadcast Receiver
        //sendService; Services

        //Implicit Intent doesn't define the name of the Component
//        Intent implicitIntent = new Intent();
//        implicitIntent.setAction("OPEN_ACTIVITY_3");
//        startActivity(implicitIntent);
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, "Hello");
        sendIntent.setType("text/plain");
        try {
            startActivity(sendIntent);
        } catch (ActivityNotFoundException e) {
            // Define what your app should do if no activity can handle the intent.
        }

    }

    /**
     * Layout is visible, but not interactable.
     * Reset or define UI values.
     */
    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart: ");
    }

    /**
     * UI is visible and the listeners are set.
     */
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: ");
    }

    /**
     * UI is visible but not interactable
     * We are showing a Popup/Dialog.
     * saving UI data, or preparing to dispose/close connections.
     */
    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: ");
    }

    /**
     * UI is no longer visible
     * 2 scenarios, stay in onStop or move to onDestroy.
     * close and dispose
     */
    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop: ");
    }

    /**
     *Remove from memory
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: ");
    }
}
