package com.example.activitytransition;

import android.app.Application;
import android.util.Log;

public class CustomApplication extends Application {
    private static final String TAG = "CustomApplication";

    /**
     * Init logger libraries
     * Init Analytic libraries
     * Init dependency injection
     */
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate: ");
    }
}
