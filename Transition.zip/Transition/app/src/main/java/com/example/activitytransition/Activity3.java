package com.example.activitytransition;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Activity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
        Intent openIntent = getIntent();

        if (openIntent != null){
            String text = openIntent.getStringExtra(Activity2.EXTRA_MESSAGE_TEXT);
            if(text != null){
                TextView display = findViewById(R.id.tv_display_message);
                display.setText(text);
            }
        }
    }
}