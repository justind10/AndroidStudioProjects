package com.example.activitytransition;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
//Select fragmented activity version of onCreate
public class Activity2 extends AppCompatActivity {
    public static final String EXTRA_MESSAGE_TEXT = "EXTRA_MESSAGE_TEXT_ACTIVITY2";
    EditText etInput;
    Button btnOpenActivity3;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        etInput = findViewById(R.id.et_input);
        btnOpenActivity3 = findViewById(R.id.btn_open_activity);

        btnOpenActivity3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = etInput.getText().toString();
                Intent openActivity3 = new Intent(Activity2.this,
                        Activity3.class);
                openActivity3.putExtra(EXTRA_MESSAGE_TEXT,text);
                startActivity(openActivity3);
            }
        });
    }
}
