package com.example.todoapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText etInputTask;
    private Button btnSaveTask;
    private ListView lvDisplayTask;
    private ArrayAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etInputTask = findViewById(R.id.et_input_task);
        btnSaveTask = findViewById(R.id.btn_save_task);
        lvDisplayTask = findViewById(R.id.lv_display_task);
        //Set anonymously
        /*btnSaveTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //user clicks execute here...
            }
        });*/

        // set parent interface
        btnSaveTask.setOnClickListener(this);
        // method reference
        // btnSaveTask.setOnClickListener(this::onClick);

        //lambda implementation
        /*btnSaveTask.setOnClickListener(view -> {
            // do something
        });*/
        adapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1);
        lvDisplayTask.setOnItemLongClickListener(
                new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?>
                                                           adapterView,
                                                   View view,
                                                   int i,
                                                   long l) {
                        // get the element position
                        //remove from adapter
                        adapter.remove(
                                adapter.getItem(
                                        i
                                )
                        );
                        return true;
                    }
                }
        );
    }


    @Override
    public void onClick(View view) {
        String text = getTextFromEditTextOrShowError();
        if(!text.isEmpty())
        {
            adapter.add(text);
            lvDisplayTask.setAdapter(adapter);
            etInputTask.getText().clear();
        }



    }


    private String getTextFromEditTextOrShowError(){
        String text = etInputTask.getText().toString();
        if (text.isEmpty())
            Toast.makeText(this, "No empty task", Toast.LENGTH_SHORT).show();

        return text;


    }
}